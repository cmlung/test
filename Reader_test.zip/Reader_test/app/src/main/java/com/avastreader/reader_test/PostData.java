package com.avastreader.reader_test;

public class PostData {
    public String postThumbUrl;
    public String postTitle;
    public String postDate;
}